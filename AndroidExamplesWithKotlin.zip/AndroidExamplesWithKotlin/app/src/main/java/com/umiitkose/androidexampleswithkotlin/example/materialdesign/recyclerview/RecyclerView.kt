package com.umiitkose.androidexampleswithkotlin.example.materialdesign.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.umiitkose.androidexampleswithkotlin.R

class RecyclerView : AppCompatActivity() {
/* Listview üzerinde item tasarımdaki her bir nesne için yeni bir instance oluşurken, recycler view 'da sadece ekranda oluşan itemlar gözükür.
* Scroll edildikçe işi biten itemlar diğer itemlarla yer değiştiriyor. Recyclerview veri vs fazla ise kesinlikle kullanılmalı.
*
* 3 Tane görünüm türü var.
*
* LinearLayoutManager = Yatay ve Dikey görünüm için
* GridLayoutManager = Grid Olarak kullanılıyor
* StaggeredLayoutManager = Farklı Boyuttaki resimler kendi boyutunda gösterilebilir.
* */
    
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recycler_view)

        val userList = arrayListOf<User>(
            User("Ali Candan", R.drawable.ic_launcher_background),
            User("Ali Candan", R.drawable.ic_launcher_background),
            User("Ali Candan", R.drawable.ic_launcher_background),
            User("Ali Candan", R.drawable.ic_launcher_background),
            User("Ali Candan", R.drawable.ic_launcher_background),
            User("Ali Candan", R.drawable.ic_launcher_background),
            User("Ali Candan", R.drawable.ic_launcher_background)

        )
    }
}
