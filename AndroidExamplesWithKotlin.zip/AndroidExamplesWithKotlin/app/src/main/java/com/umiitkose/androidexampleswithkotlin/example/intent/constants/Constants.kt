package com.umiitkose.androidexampleswithkotlin.example.intent.constants

object Constants {

    val EXTRA_NAME = "extra_name"
}