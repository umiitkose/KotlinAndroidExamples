package com.umiitkose.androidexampleswithkotlin.example.materialdesign.recyclerview

data class User(var name: String, var image: Int)
