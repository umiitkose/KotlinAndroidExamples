package com.umiitkose.androidexampleswithkotlin.example.materialdesign.recyclerview

import android.view.View


class UserAdapter : RecyclerView.Adapter<UserAdapter.ViewHolder>{






    class ViewHolder(view: View): RecyclerView.ViewHolder(view){



    }

}