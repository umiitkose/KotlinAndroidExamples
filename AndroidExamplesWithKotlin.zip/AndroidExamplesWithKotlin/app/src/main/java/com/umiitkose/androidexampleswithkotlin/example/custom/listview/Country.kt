package com.umiitkose.androidexampleswithkotlin.example.custom.listview

data class Country (var name: String, var flag: Int)
